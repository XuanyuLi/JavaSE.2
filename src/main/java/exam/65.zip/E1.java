package exam;

/**
 * Created by Administrator on 2017/3/18.
 */
public class E1 {
    public static void main(String[] args) {
        System.out.println("This is my first Java application!");
    }
}
